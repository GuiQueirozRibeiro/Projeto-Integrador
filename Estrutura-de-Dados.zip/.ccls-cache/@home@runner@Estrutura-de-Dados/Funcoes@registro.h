#ifndef _REGISTRO_LIVRO_
#define _REGISTRO_LIVRO_

#include <stdio.h>

#include "../Animacoes/Funcoes_Anin/term.h"
#include "../Listas/structs.h"

//-------------------FUNCIONALIDADES--------------------

void UsuarioCodLivros(User* usuario);

//-----------------------FUNÇÕES------------------------

void UsuarioCodLivros(User* usuario) {
    if(!usuario)
        return;
    FILE* arq = fopen("Dados/regLivros.txt", "rb");
    if(!arq) {
        printf("Falha ao abrir arquivo: 'regLivros.txt'\n");
        sleep(2);
        return;
    }
}

#endif