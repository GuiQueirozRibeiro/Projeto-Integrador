#ifndef _ALUGUEL_
#define _ALUGUEL_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#include "structs.h"
#include "term.h"

//-------------------FUNCIONALIDADES--------------------

void AlugarLivro(User *usuario, char titulo[30]);
void DevolverLivro(User *usuario, char titulo[30], char check);
void MeusLivros(User *usuario);
char ChecaDia(User *usuario);
char ChecaAluguel(User *usuario, char titulo[30]);

//-----------------------FUNÇÕES------------------------

void AlugarLivro(User *usuario, char titulo[30]) {
    int dia_alugado;
    int check = 0;

    struct tm *data_hora_atual;     
 
    time_t segundos;
    time(&segundos);   

    data_hora_atual = localtime(&segundos);
    dia_alugado = data_hora_atual->tm_yday;

    FILE * fregistro = fopen("Dados/aluguel.txt", "a");

    if(!fregistro) {
        printf("Falha ao alugar livro.\n");
        sleep(3);
        exit(1);
    }
    do {
        if (titulo[0]==0) {
            //buscar livro
            system("clear");
            printf("Digite o nome do livro: ");
            fgets(titulo, 30, stdin);
            strtok(titulo, "\n");
        }
        else {
            system("clear");
            printf("Digite o nome do livro: ");
            fgets(titulo, 30, stdin);
            strtok(titulo, "\n");
        }
        check = ChecaAluguel(usuario, titulo);
    } while(!check);

    fprintf(fregistro, "%s:%s:%i\n", usuario->login, titulo, dia_alugado);
    //reduzir quantidade do livro

    system("clear");
    printf("Livro Alugado com sucesso!");
    printf("\n\nVoltando para o menu...\n");
    sleep(3);

    fclose(fregistro);
    return;
}

void DevolverLivro(User *usuario, char titulo[30], char check) {
    char linha[80] = {0};
    char login[80] = {0};
    char cmp[30] = {0};
    char* ptr;
    int i = 0;

    system("clear");

    if (check) {
        //buscar livro - meus livros
        printf("Digite o nome do livro: ");
        fgets(titulo, 30, stdin);
        strtok(titulo, "\n");
    }
    if (!check) {
        printf("Livro fora do prazo de devolução\nPague a multa pendente!");
        printf("\n\nMulta = R$ 999,99");
        printf("\nPressione enter para pagar!");
        getchar();
        system("clear");
        printf("Pagamento realizado!\n\n");
        
    }
    struct tm *data_hora_atual;  

    time_t segundos;
    time(&segundos);   

    data_hora_atual = localtime(&segundos);

    FILE * input = fopen("Dados/aluguel.txt", "r");
    FILE * output = fopen("Dados/transferindo.txt", "w");

    if(!input || !output) {
        printf("Erro na abertura do arquivo\n");
        exit(1);
    }
    while(!feof(input)) {

        if(feof(input))
            break;
        memset(linha, 0, 80);
        memset(login, 0, 80);

        fgets(linha, 57, input);

        strcpy(login, linha);
        ptr = strtok(login, ":");

        if(strcmp(login, usuario->login) == 0) {
            ptr = strtok(NULL, ":");
            strcpy(cmp, ptr);

            if(strcmp(cmp, titulo) != 0)
                fputs(linha, output);
            else
                i++;
        }
        else 
            fputs(linha, output);
    }
    fclose(input);
    fclose(output);
        
    remove("Dados/aluguel.txt");
    rename("Dados/transferindo.txt", "Dados/aluguel.txt");

    system("clear");

    if (i || !check)
        printf("\nLivro - %s devolvido com sucesso!\n", titulo);
    else
        printf("\nLivro - %s não foi alugado!\n", titulo);
    printf("\nVoltando para o menu...\n");
    sleep(4);
}

void MeusLivros(User *usuario) {
    char linha[80] = {0};
    char check[80] = {0};
    char* ptr;
    int dia;
    int i = 0;

    struct tm *data_hora_atual;  

    time_t segundos;
    time(&segundos);   

    data_hora_atual = localtime(&segundos);

    FILE * fleitura = fopen("Dados/aluguel.txt", "r");

    if(!fleitura) {
        printf("Erro na abertura do arquivo\n");
        exit(1);
    }
    system("clear");

    tc_echo_off();
    tc_canon_off();

    HideCursor();
    
    printf("Livros Alugados\n");
    int feof(FILE * fleitura);

    while(!feof(fleitura)) {

        if(feof(fleitura))        
            break;
        memset(linha, 0, 80);
        memset(check, 0, 80);

        fgets(linha, 57, fleitura);

        for(size_t j = 0; j<57; j++) {
            if(linha[j] != '\n')
                continue;
            linha[j] = 0;
            break;
        }
        strcpy(check, linha);
        ptr = strtok(check, ":");

        if(strcmp(check, usuario->login) == 0) {
            i++;
            ptr = strtok(NULL, ":");
            printf("\n%d- %s", i, ptr);

            ptr = strtok(NULL, ":");
            dia = atoi(ptr);

            if (dia > data_hora_atual->tm_yday)
                printf(" - restam %d dias", dia - (data_hora_atual->tm_yday + 358));
            else
                printf(" - restam %d dias", (7 + dia) - data_hora_atual->tm_yday);
        }
    }
    printf("\n\nPressione qualquer tecla para voltar... \n");
    getchar();

    fclose(fleitura);
}

char ChecaDia(User *usuario) {
    char linha[80] = {0};
    char check[80] = {0};
    char titulo[30] = {0};
    char* ptr;
    int dia;

    struct tm *data_hora_atual;     
 
    time_t segundos;
    time(&segundos);   

    data_hora_atual = localtime(&segundos);

    FILE * fleitura = fopen("Dados/aluguel.txt", "r");

    if(!fleitura) {
        printf("Erro na abertura do arquivo\n");
        exit(1);
    }
    while(!feof(fleitura)) {

        if(feof(fleitura))
            break;
        memset(linha, 0, 80);
        memset(check, 0, 80);

        fgets(linha, 57, fleitura);

        for(size_t j = 0; j<57; j++) {
            if(linha[j] != '\n')
                continue;
            linha[j] = 0;
            break;
        }
        strcpy(check, linha);
        ptr = strtok(check, ":");

        if(strcmp(check, usuario->login) == 0) {
            ptr = strtok(NULL, ":");
            strcpy(titulo, ptr);
            ptr = strtok(NULL, ":");
            dia = atoi(ptr);

            if (dia > data_hora_atual->tm_yday) {
                if (dia >= data_hora_atual->tm_yday+358) {
                    fclose(fleitura);
                    DevolverLivro(usuario, titulo, 0);
                    return 0;
                }
            }
            else if(dia +7 <= data_hora_atual->tm_yday) {
                fclose(fleitura);
                DevolverLivro(usuario, titulo, 0);
                return 0;
            }
        }
    }
    fclose(fleitura);
    return 1;
}

char ChecaAluguel(User *usuario, char titulo[30]) {
    char linha[80] = {0};
    char check[80] = {0};
    char *ptr;

    FILE * fleitura = fopen("Dados/aluguel.txt", "r");

    if(!fleitura) {
        printf("Erro na abertura do arquivo\n");
        exit(1);
    }
    while(!feof(fleitura)) {

        if(feof(fleitura))
            break;
        memset(linha, 0, 80);
        memset(check, 0, 80);

        fgets(linha, 57, fleitura);

        for(size_t j = 0; j<57; j++) {
            if(linha[j] != '\n')
                continue;
            linha[j] = 0;
            break;
        }
        strcpy(check, linha);
        ptr = strtok(check, ":");

        if(strcmp(check, usuario->login) == 0) {
            ptr = strtok(NULL, ":");

            if(strcmp(titulo, ptr) == 0) {
                printf("\nVocê já alugou este livro, tente outro!\n");
                sleep(2);
                return 0; 
            }
        }
    }
    return 1;
}

#endif