#ifndef _LOGIN_
#define _LOGIN_
#include "Structs.h"
#include <stdlib.h>
#include <stdio.h>

User login(User conta, Livro livro){
    unsigned long long x; char y[30];
    char check;
    do{
        system("clear");
        printf("LOGIN\n--------------------");
        printf("Insira sua matricula: ");
        scanf("%llu", &x);
        printf("\nInsira sua senha: ");
        scanf("%29s", y);
        if (conta.matricula == x)
        {
            check = 1;
        }
            
    } while (check == 0);
}

void cadastro(User conta){
  unsigned long long mat;
  char senha[30];
  system("clear");
  printf("CADASTRO\n--------------------");
  printf("Insira seu matricula: ");
  scanf("%llu", &mat);
  printf("\nInsira sua senha: ");
  scanf("%s", senha);
}

#endif