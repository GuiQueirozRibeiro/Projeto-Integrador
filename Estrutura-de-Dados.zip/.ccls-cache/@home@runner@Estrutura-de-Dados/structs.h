#ifndef _STRUCTS_
#define _STRUCTS_

typedef struct {
    char login[30];
    char senha[41];
    unsigned int livros[20];
    char admin;
} User;

typedef struct {
    char nome[51];
    char biografia[501];
    unsigned long long cod;
    unsigned long long livros_escritos[999];
}Autor;

typedef struct {
    unsigned long long codigo;
    char titulo[51];
    unsigned long long autor;
    unsigned short int quantidade;
    unsigned short int alugado;
} Livro;

#endif