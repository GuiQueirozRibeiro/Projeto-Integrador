#define _GNU_SOURCE
#define __USE_BSD /* usleep() */

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>

#include "aluguel.h"
#include "biblioteca.h"
#include "crypto.h"
#include "desenharLivro.h"
#include "listaAutor.h"
#include "listaLivro.h"
#include "login.h"
#include "structs.h"
#include "term.h"

#define HideCursor() printf("\e[?25l");
#define ShowCursor() printf("\e[?25h");

#ifdef __WIN32__
    #include <windows.h>
    void SetCursorPosition(short x, short y) {
        COORD Coord;
        Coord.X = XPos;
        Coord.Y = YPos;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), Coord);
    }
#else
    void SetCursorPosition(short x, short y) {
        printf("\033[%d;%dH", y, x);
    }
#endif

#if defined __USE_BSD || defined __USE_XOPEN_EXTENDED

extern __useconds_t ualarm (__useconds_t __value, __useconds_t __interval) __THROW;

extern int usleep (__useconds_t __useconds);
#endif

void ClearEndLine();
void AninLoading();

//-----------------------MENUS--------------------------

void MenuAdmin(User *usuario);
void MenuCliente(User *usuario);

//-------------------FUNCIONALIDADES--------------------

void MostrarLivro(Livro livro);
void MostrarAutor(Autor Autor);
void AdicionarLivro();
void RemoverLivro();
void ProcurarLivro(char login[30]);
void ProcurarAutor();
void TornarAdmin();
void MostrarBiblioteca();
User* Login(char);

//------------------------MAIN--------------------------

int main(void) {
    User * usuario = NULL;
    char escolha;
    int opc = 1;
    int status;
    char fim = 0;

    while(!fim) {
        tc_echo_off();
        tc_canon_off();

        HideCursor();
        printf("\e[H\e[2J");
        if(usuario) free(usuario);
        do {
            SetCursorPosition(1,1);
            DrawTopoLivro();
            
            TextDraw("MENU PRINCIPAL", TC_GRN);
            DrawLine(1);
            char* ops[4] = {"CADASTRO", "LOGIN", "LOGIN ADMIN", "SAIR"};

            for(int i = 0; i<4; i++) {
                if(opc - 1 == i)
                    TextDraw(ops[i], TC_RED);
                else TextDraw(ops[i], TC_GRN);
            }
            DrawLine(9);
            DrawBottomLivro();
            printf("\033[0m");

            escolha = getchar();

            if(escolha == 65 && opc > 1)
                opc--;
            if(escolha == 66 && opc < 4)
                opc++;

        } while (escolha != 10);

        tc_echo_on();
        tc_canon_on();
        ShowCursor();

        switch (opc) {
            case 1:
                Registrar(usuario);
                break;
            case 2:
                usuario = Login(0);
                if(!usuario){
                    printf("\e[H\e[2J");
                    DrawTopoLivro();
                    TextDraw("Login ou Senha invalidos.", TC_YEL);
                    DrawBottomLivro();
                    getchar();
                    break;
                }
                AninLoading();
                MenuCliente(usuario);
                break;
            case 3:
                usuario = Login(1);
                if(!usuario){
                    printf("\e[H\e[2J");
                    DrawTopoLivro();
                    TextDraw("Login ou Senha invalidos.", TC_YEL);
                    DrawBottomLivro();
                    getchar();
                    break;
                }
                AninLoading();
                MenuAdmin(usuario);
                break;
            case 4:
                system("clear");
                printf("Obrigado por utilizar nosso sistema! ( ͡~ ͜ʖ ͡°)\n");
                fim = 1;
                break;
            default:
                printf("\n\nSelecione uma opção válida!!!\n\n");
        }
    }
    return 0;
}

//-----------------------FUNÇÕES------------------------

User* Login(char admin){
    char resp = 0;
    char opc = 0;
    char tamL = 0;
    char tamS = 0;

    User* usuario = (User*)malloc(sizeof(User));

    if(!usuario) exit(15);
    
    usuario->admin = admin;
    memset(usuario->senha, 0, strlen(usuario->senha));
    memset(usuario->login, 0, strlen(usuario->login));
    
    printf("\e[H\e[2J");
    tc_echo_off();
    tc_canon_off();
    HideCursor();

    while(resp != 10){
        SetCursorPosition(1,1);
        DrawTopoLivro();
        DrawLine(1);
        if(opc) TextDraw("LOGIN:", TC_GRN);
        else TextDraw("LOGIN:", TC_RED);
        
        if(!opc) TextDraw(usuario->login, TC_BLK);
        else TextDraw(usuario->login, TC_GRN);
        
        DrawLine(1);
        
        if(!opc) TextDraw("SENHA:", TC_GRN);
        else TextDraw("SENHA:", TC_RED);

        if(!opc) TextDrawWithMask(usuario->senha, TC_GRN, '*');
        else TextDrawWithMask(usuario->senha, TC_BLK, '*');
        
        DrawLine(4);
        DrawBottomLivro();

        resp = getchar();

        switch(resp){
            case 9:
                opc = !opc;
            break;
            case 10:
                opc = !opc;
                if(!tamS) resp = 0;
            break;
            case 8:
            case 127:
                if(!opc && tamL > 0)
                    usuario->login[--tamL] = 0;
                if(opc && tamS > 0)
                    usuario->senha[--tamS] = 0;
            break;
            default:
                if((resp >= 'a' && resp <= 'z') ||
                    (resp >= 'A' && resp <= 'Z') ||
                    (resp >= '0' && resp <= '9'))
                {
                    if(!opc && tamL < 29)
                        usuario->login[tamL++] = resp;
                    if(opc && tamS < 19)
                        usuario->senha[tamS++] = resp;
                }
            break;
        }
    }
    if(Autenticar(usuario))
        return usuario;
    else return NULL;
}

void AninLoading(){
    for(int i = 0; i <= 100; i++) {
        printf("\e[H\e[2J");
        printf("Carreagando informações [");

        for (int j = 0; j<10; j++) {
            if (j < i/10) {
                if (i/10 < 6)
                    printf("\033[31m▮");
                else
                    printf("\033[32m▮");
            }
            else
                printf("\033[0m ");
        }
        printf("\033[0m]");
        printf("%i %%",i);
        fflush(stdout);
        usleep(50000);
    }
    printf("\n\nDados carregados!\n");
    printf("Entrando no menu...\n");
    sleep(3);
}

void MenuCliente(User *usuario) {
    char resp;
    char fim = 0;
    int opc = 0;
    int status = 0;
    char* ops[] = {"Biblioteca", "Buscar Livro", "Procurar Autor", "Alugar Livro", "Devolver Livro", "Meus Livros", "Sair"};
    while(!fim) {
        char titulo[51]={0};

        tc_echo_off();
        tc_canon_off();

        HideCursor();
        printf("\e[H\e[2J");

        do {
            status = ChecaDia(usuario);
        } while(!status);

        do {
            SetCursorPosition(1,1);
            DrawTopoLivro();
            TextDraw("MENU", TC_GRN);
            DrawLine(1);

            for(int i = 0; i < 7; i++){
                if(opc == i)
                    TextDraw(ops[i], TC_RED);
                else TextDraw(ops[i], TC_GRN);
            }
            DrawLine(6);
            DrawBottomLivro();
            printf(TC_RST);

            resp = getchar();

            if(resp == 65 && opc > 0)
                opc--;
            else if(resp == 66 && opc < 6)
                opc++;
        } while (resp != 10);

        ShowCursor();
        tc_echo_on();
        tc_canon_on();

        switch (opc) {
            case 0:
                MostrarBiblioteca();
                break;
            case 1:
                ProcurarLivro(usuario->login);
                break;
            case 2:
                ProcurarAutor();
                break;
            case 3:
                AlugarLivro(usuario, titulo);
                break;
            case 4:
                DevolverLivro(usuario, titulo, 1);
                break;
            case 5:
                MeusLivros(usuario);
                break;
            case 6:
                fim = 1;
                break;
            default:
                printf("\n\nSelecione uma opção válida!!!\n\n");
        }
    }
}

void MenuAdmin(User *usuario) {
    char resp;
    char fim = 0;
    int opc = 0;
    char* ops[] = {"Adicionar Livro", "Remover Livro", "Procurar Livro", "Procurar Autor", "Tornar Admin", "Criar Admin", "Biblioteca", "Sair"};

    while(!fim) {
        tc_echo_off();
        tc_canon_off();

        printf("\e[H\e[2J");
        HideCursor();

        do {
            SetCursorPosition(1,1);
            DrawTopoLivro();
            TextDraw("MENU", TC_GRN);
            DrawLine(1);

            for(int i = 0; i < 8; i++) {
                if(opc == i)
                    TextDraw(ops[i], TC_RED);
                else
                    TextDraw(ops[i], TC_GRN);
            }
            DrawLine(6);
            DrawBottomLivro();
            printf(TC_RST);

            resp = getchar();

            if(resp == 65 && opc > 0)
                opc--;
            else if(resp == 66 && opc < 7)
                opc++;
        } while (resp != 10);

        opc++;
        tc_echo_on();
        tc_canon_on();

        switch (opc) {
            case 1:
                AdicionarLivro();
                break;
            case 2:
                RemoverLivro();
                break;
            case 3:
                ProcurarLivro(usuario->login);
                break;
            case 4:
                ProcurarAutor();
                break;
            case 5:
                TornarAdmin(1);
                break;
            case 6:
                TornarAdmin(0);
                break;
            case 7:
                MostrarBiblioteca();
                break;
            case 8:
                fim = 1;
                break;
            default:
                printf("\n\nSelecione uma opção válida!!!\n\n");
        }
    }
}

void MostrarLivro(Livro livro) {
    tc_echo_off();
    tc_canon_off();
    system("clear");

    printf("Nome: %s\n", livro.titulo);
    printf("Autor: %llu\n", livro.autor);
    printf("Cod: %llu\n", livro.codigo);
    getchar();
}

void MostrarAutor(Autor Autor) {
    Livro livro;

    system("clear");
    printf("Nome: %s\n", Autor.nome);
    printf("Biografia:\n%s\n", Autor.biografia);
    printf("Livros: ");

    for(int i = 0; Autor.livros_escritos[i]; i++) {
        livro = BuscarLivroCod(Autor.livros_escritos[i]);
        if(!livro.codigo)
            continue;
        printf("[%s] ", livro.titulo);
    }
    getchar();
}

void AdicionarLivro() {
    Livro livro;
    listaLivro* lista = InitList(lista);

    char resp = 0;
    char quant = 0;
    char posY = 0;

    tc_echo_off();
    tc_canon_off();

    while(resp != 13) {
        char count = 0;

        printf(TC_WHT);
        system("clear");
        printf("NOVO LIVRO\n--------------------\n");
        printf("Título: %s", livro.titulo);
    
        for(t_noL* no = lista->inicio; no != lista->fim; no = no->proximo) {
            count++;
            printf(TC_WHT);

            if(posY == count)
                printf(TC_RED);
            printf("\n%s", no->livro.titulo);
        }
        resp = getchar();

        switch(resp) {
            case 27:
                if(!kbhit())
                    return;

                getchar();
                resp = getchar();

                switch(resp) {
                    case 'A':
                        if(posY < lista->size && lista->size) posY--;
                        break;
                    case 'B':
                        if(posY && lista->size) posY++;
                        break;
                }
                break;
            case 8:
            case 127:
                if(!quant)
                    break;
                livro.titulo[--quant] = 0;
                break;
            default:
                if(quant >= 50)
                    break;
                livro.titulo[quant++] = resp;
                if(quant >= 3) {
                    ClearList(lista);
                    lista = Buscar_Livro(livro.titulo, 1, 3);
                }
            break;
        }
    }
    if(!Add_Livro(livro))
        printf("Falha ao Adicionar Livro!");
}

void RemoverLivro() {
    char nome[41];
    nome[40] = 0;

    tc_echo_on();
    tc_canon_on();
    system("clear");

    printf("Nome do livro: ");
    scanf("%40[^\n]%*c", nome);

    Remove_Livro(nome);
}

void ProcurarLivro() {

    size_t pagina = 0;
    size_t quant = 0;

    char livroPorPagina = 20;
    char buff[41] = {0};
    char posiY = 0;
    unsigned char resp;
    listaLivro *livros = InitList(livros);

    tc_echo_off();
    tc_canon_off();

    while(resp != 13) {
        system("clear");
        DrawTopoLivro();
        //TextDrawLivro()
        printf("Digite o nome do Livro: %s ", buff);

    //Mostra as opções de complemento
        if(livros && livros->size) {
            char count = 0;
            for(t_noL* l = livros->inicio; l != livros->fim; l = l->proximo) {
                printf(TC_BLU);
                count++;
                if(posiY == count)
                    printf(TC_RED);
                printf("\n%s", l->livro.titulo);
            }
        }
        resp = getchar();

        switch(resp) {
            case 27: //return;
                if(!kbhit()) {
                    printf(TC_WHT);
                    return;
                }
            getchar();
            resp = getchar();

                switch(resp) {
                    case 'A':
                        if(posiY)
                            posiY--;
                        break;
                    case 'B':
                        if(posiY < livros->size)
                            posiY++;
                        break;
                }
            break;
            case 8:
            case 127:
                if(!quant)
                    break;
                quant--;
                buff[quant] = 0;
                break;
            default:
                if((resp >= '0' && resp <= '9') ||
                   (resp >= 'A' && resp <= 'Z') ||
                   (resp >= 'a' && resp <= 'z') || resp == 32) {
                    if(quant >= 40)
                        break;
                    posiY = 0;
                    buff[quant++] = resp;
                    Upper_Case(buff);

                    if(quant >= 3) {
                        ClearList(livros);
                        livros = Buscar_Livro(buff, pagina, 3);
                    }
                }
            break;
        }
    }

    if(posiY--){
        t_noL* l = livros->inicio;
        while(posiY--) l = l->proximo;
        MostrarLivro(l->livro);
        DeleteList(livros);
        return;
    }
    ClearList(livros);
    livros = Buscar_Livro(buff, pagina, livroPorPagina);
    printf(TC_WHT);

    
    getchar();
    DeleteList(livros);
}

void ProcurarAutor() {
    listaAutor* autores = NULL;
    InitListA(autores);

    char autor[100] = {0};
    char resp = 0;
    int posY = 0;
    size_t quant = 0;

    while(resp != 13 || quant < 3) {
        int count = 0;

        printf(TC_WHT);
        system("clear");
        printf("Autor: %s", autor);

        for(t_noA* no = autores->inicio; no != autores->fim; no = no->proximo) {
            if(!no)
                break;
            count++;
            printf(TC_WHT);

            if(count == posY)
                printf(TC_RED);

            printf("\n%s", no->autor.nome);
        }
        resp = getchar();

        switch(resp) {
            case 27:
            if(!kbhit()) {
                printf(TC_WHT);
                return;
            }
            getchar();
            resp = getchar();

            if(!autores->size)
                break;

            switch(resp) {
                case 'A':
                    if(posY) posY--;
                    break;
                case 'B':
                    if(posY < autores->size) posY++;
                    break;
                }
            break;
            case 127:
            case 8:
                if(!quant) break;
                autor[--quant] = 0;
                break;
            default:
                if((resp >= '0' && resp <= '9') ||
                   (resp >= 'a' && resp <= 'z') ||
                   (resp >= 'A' && resp <= 'z')) {

                    if(quant < 49) {
                        posY = 0;
                        autor[quant++] = resp;
                        Upper_Case(autor);

                        if(quant > 3) {
                            ClearListA(autores);
                            BuscarAutor(autores, autor, 3);
                        }
                    }
                }
            break;
        }
    }

    if(posY) {
        for(t_noA* no = autores->inicio; no != autores->fim; no = no->proximo) {
            posY--;
            if(!posY){
                MostrarAutor(no->autor);
                goto jmp;
                return;
            }
        }
    }
    BuscarAutor(autores, autor, 20);

    if(!autores->size) {
        system("clear");
        printf("Nada encontrado para '%s'.", autor);
        goto jmp;
        getchar();
        return;
    }
    t_noA* leitura = autores->inicio;
    size_t num = 0;
    resp = 0;

    while(1) {
        t_noA* no = autores->inicio;
        size_t cont = 0;

        printf(TC_WHT);
        system("clear");

        while(no) {
            printf(TC_WHT);
            if(cont++ == num) {
                printf(TC_RED);
                leitura = no;
            }
            printf("%s\n", no->autor.nome);
        }
        resp = getchar();

        if(resp == 27) {
            if(!kbhit())
                return;
            getchar();
            resp = getchar();

            if(resp == 'A' && num)
                num--;
            else if(resp == 'B' && num < autores->size - 1)
                num++;
        }
    }
    MostrarAutor(leitura->autor);
    jmp:
    ClearListA(autores);
    free(autores);
}

void TornarAdmin(int opc) {
    char cmp1[57] = {0}, cmp2[57] = {0}, login[30] = {0}, senha[20] = {0};
    int status, a, ch, j = 0;
    unsigned long int cripto;

    system("clear");
    printf("Digite o login: ");

    do {
        status = 1;
        fgets(login, 30, stdin);

        for (int i=0; i<strlen(login); i++) {
            if (login[i] == ':') {
                status = 0;
                printf("\n\nErro: login inválido!\n");
                printf("Tente outro login: ");
                strtok(login, "\n");
            }
        }
    } while(!status);

    for(size_t i = 0; i<30; i++) {
        if(login[i] != '\n')
            continue;
        login[i] = 0;
        break;
    }
    if(opc) {
        VirarAdmin(login);
        return;
    }
    tc_echo_off();
    tc_canon_off();

    printf("Digite a senha: ");

    while(1) {
		ch = getchar();

		if(ch == 10) {
            if(j == 0) {   
                system("clear");
                printf("Erro senha vazia!\n");
                printf("Digite uma senha válida!\n");

                sleep(2);

                system("clear");
                printf("Digite o login: %s", login);
			    printf("\nDigite a senha: ");
                continue;
            }
            break;
        }
		if(ch == 127) {
			if(!j)
                continue;
			--j;
            senha[j] = 0;

			system("clear");
            printf("Digite o login: %s", login);
			printf("\nDigite a senha: ");

			for(a = 0; a < j; a++)
				printf("*");
			continue;
		}
        if(ch == 58) {
            system("clear");
            printf("Erro senha inválida!\n");
            printf("Caractere ':' não é permitido!\n");
			printf("Tente outro caractere\n");

            sleep(2);

            system("clear");
            printf("Digite o login: %s", login);
			printf("\nDigite a senha: ");

			for(a = 0; a < j; a++)
				printf("*");
			continue;
        }
        if(j == 20) {
            system("clear");
            printf("Erro Limite de caracteres atingidos!\n");
            printf("Modifique sua senha ou apenas aperte enter para continuar\n");

            sleep(2);

            system("clear");
            printf("Digite o login: %s", login);
			printf("\nDigite a senha: ");

			for(a = 0; a < j; a++)
				printf("*");
			continue;
        }
        printf("*");
	    senha[j] = ch;
		j++;
	}
    tc_echo_on();
    tc_canon_on();

    for(int i = 0; i < 20; i++) {
        if(i >= j)
            senha[i] = 0;
        if(senha[i] != '\n')
            continue;
        senha[i] = 0;
        break;
    }
    Criptografar(senha);

    strcpy(cmp1, login);
    strcat(cmp1, ":");
    strcat(cmp1, senha);
    strcpy(cmp2, cmp1);

    strcat(cmp1, ":0");
    strcat(cmp2, ":1");

    CriarAdmin(cmp1, cmp2, login);
}

void MostrarBiblioteca() {
    int resp = 0;
    int pagina = 0;
    int totalPag;

    tc_echo_on();
    tc_canon_on();

    do {
        listaLivro* livros = ShowBiblioteca(pagina, &totalPag, 20);
        char i = 1;
        char c, d;

        system("clear");
        if(!livros->size) {
            printf("Erro: Nenhum livro encontrado.\n");
            getchar();
            break;
        }
        SetCursorPosition(1, 2);

        for(t_noL* node = livros->inicio; i<= livros->size;node = node->proximo)
            printf("%d - %s\n", i++, node->livro.titulo);

        resp = 0;

        SetCursorPosition(1,1);
        printf("Pagina <%d - %d>(0-Voltar, '+' ou '-' para pagina): ", pagina+1, totalPag);

        while((c = getchar()) != '\n') {
            resp *= 10;
            if(c >= '0' && c <= '9') {
                if(d == '+' || d == '-')
                    resp = 0;
                resp += c - '0';
            }
            else {
                resp = c;
                d = c;
            }
            if(resp == '+' && (pagina+1) < totalPag)
                pagina++;

            else if(resp == '-' && (pagina+1) > 1)
                pagina--;

            else if(resp >= 1 && resp <= livros->size) {
                t_noL* node = livros->inicio;

                for(int i = 1; i<resp; i++)
                    node = node->proximo;
                MostrarLivro(node->livro);
            }
        }
    } while(resp != 0);
}