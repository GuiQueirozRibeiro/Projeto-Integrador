#ifndef _KEYB_H
#define _KEYB_H

#include <thread>
#include "listaKey.h"
#include "term.h"

char started = 0;
std::thread th;
listaKey* pressed = NULL;

void UpdateKey() {
  if(!pressed) pressed = InitList(pressed);
  started = 1;
  char resp;
  tc_canon_off();
  tc_echo_off();
  while(started){
    resp = getchar();
    PushBack(pressed, resp);
  }
}

void StartKeyboard() {
  th = std::thread(UpdateKey);
  
}

char HasKey() {
  if(!pressed || !started) return 0;
  return (pressed->size != 0);
}

unsigned char GetKey() {
  if(!pressed || !started) return 0;
  if(pressed->size) {
    unsigned char resp = pressed->inicio->key;
    PopFront(pressed);
    return resp;
  }
  return 0;
}

void GetString(char* buffer, unsigned int size){
  if(!pressed || !started) return;
  unsigned int cont = 0;
  for(t_key* k = pressed->inicio; k != pressed->fim; k = pressed->inicio) {
    if(cont == size || k->key == 13) break;
    buffer[cont++] = k->key;
    PopFront(pressed);
  }
}

void GetInteger(int* ptr){
  if(!pressed || !started) return;
  int val = 0;
  int max = 0x7fffffff;
  char negativo = 0;
  for(t_key* k = pressed->inicio; k != pressed->fim; k = pressed->inicio){
    if(k->key == 13) break;
    if(k->key == '-' && !negativo) negativo = 1;
    else if(k->key >= '0' && k->key <= '9') {
      if((max - val) < 90) {
        val = max;
        break;
      }
      val *= 10;
      if((max - val) < (k->key - '0')) {
        val = max;
        break;
      }
      val += k->key - '0';
    }else break;
    PopFront(pressed);
  }
  if(negativo) val = -val;
  *ptr = val;
}

void GetInteger(short* ptr) {
  if(!pressed || !started) return;
  short val = 0;
  short max = 0x7fff;
  char negativo = 0;
  for(t_key* k = pressed->inicio; k != pressed->fim; k = pressed->inicio){
    if(k->key == 13) break;
    if(k->key == '-' && !negativo) negativo = 1;
    else if(k->key >= '0' && k->key <= '9') {
      if((max - val) < 90) {
        val = max;
        break;
      }
      val *= 10;
      if((max - val) < (k->key - '0')) {
        val = max;
        break;
      }
      val += k->key - '0';
    }else break;
    PopFront(pressed);
  }
  if(negativo) val = -val;
  *ptr = val;
}

void GetInteger(long long* ptr){
  if(!pressed || !started) return;
  long long val = 0;
  long long max = 0x7fffffffffffffff;
  char negativo = 0;
  for(t_key* k = pressed->inicio; k != pressed->fim; k = pressed->inicio){
    if(k->key == 13) break;
    if(k->key == '-' && !negativo) negativo = 1;
    else if(k->key >= '0' && k->key <= '9') {
      if((max - val) < 90) {
        val = max;
        break;
      }
      val *= 10;
      if((max - val) < (k->key - '0')) {
        val = max;
        break;
      }
      val += k->key - '0';
    }else break;
    PopFront(pressed);
  }
  if(negativo) val = -val;
  *ptr = val;
}

void GetUInteger(unsigned int* ptr){
  if(!pressed || !started) return;
  unsigned int val = 0;
  unsigned int max = 0xffffffff;
  char negativo = 0;
  for(t_key* k = pressed->inicio; k != pressed->fim; k = pressed->inicio){
    if(k->key == 13) break;
    if(k->key == '-' && !negativo) negativo = 1;
    else if(k->key >= '0' && k->key <= '9') {
      if((max - val) < 90) {
        val = max;
        break;
      }
      val *= 10;
      if((max - val) < (k->key - '0')) {
        val = max;
        break;
      }
      val += k->key - '0';
    }else break;
    PopFront(pressed);
  }
  if(negativo) val = -val;
  *ptr = val;
}

void GetUInteger(unsigned short* ptr){
  if(!pressed || !started) return;
  unsigned short val = 0;
  unsigned short max = 0xffff;
  char negativo = 0;
  for(t_key* k = pressed->inicio; k != pressed->fim; k = pressed->inicio){
    if(k->key == 13) break;
    if(k->key == '-' && !negativo) negativo = 1;
    else if(k->key >= '0' && k->key <= '9') {
      if((max - val) < 90) {
        val = max;
        break;
      }
      val *= 10;
      if((max - val) < (k->key - '0')) {
        val = max;
        break;
      }
      val += k->key - '0';
    }else break;
    PopFront(pressed);
  }
  if(negativo) val = -val;
  *ptr = val;
}

void GetUInteger(unsigned long long* ptr){
  if(!pressed || !started) return;
  unsigned int val = 0;
  unsigned int max = 0xffffffff;
  char negativo = 0;
  for(t_key* k = pressed->inicio; k != pressed->fim; k = pressed->inicio){
    if(k->key == 13) break;
    if(k->key == '-' && !negativo) negativo = 1;
    else if(k->key >= '0' && k->key <= '9') {
      if((max - val) < 90) {
        val = max;
        break;
      }
      val *= 10;
      if((max - val) < (k->key - '0')) {
        val = max;
        break;
      }
      val += k->key - '0';
    }else break;
    PopFront(pressed);
  }
  if(negativo) val = -val;
  *ptr = val;
}

void GetFloat(float* ptr){
  if(!pressed || !started) return;
  float val = 0;
  unsigned int digitos = 0;
  unsigned int flutuante = 0;
  char negativo = 0;
  char ponto = 0;
  for(t_key* k = pressed->inicio; k != pressed->fim; k = pressed->inicio){
    if(k->key == 13) break;
    if(k->key == '-' && !negativo) negativo = 1;
    else if(k->key >= '0' && k->key <= '9') {
      if(k->key == '.'){
        if(ponto) break;
        ponto = 1;
        PopFront(pressed);
        continue;
      }
      if(!ponto){
        digitos *= 10;
        digitos += k->key - '0';
      }else{
        flutuante *= 10;
        flutuante += k->key;
      }
    }else break;
    PopFront(pressed);
  }
  if(negativo) val = 32 << 1;
  unsigned int exp = 127;
  
  
  
  *ptr = val;
}
#endif