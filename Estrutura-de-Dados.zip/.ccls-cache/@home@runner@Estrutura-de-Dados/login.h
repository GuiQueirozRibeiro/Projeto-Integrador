#ifndef _LOGIN_
#define _LOGIN_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "crypto.h"
#include "structs.h"
#include "term.h"

//-------------------FUNCIONALIDADES--------------------

char Registrar(User *usuario);
char Autenticar(User* usuario);
char ChecaLogin(User *usuario);
void VirarAdmin(char login[30]);
void CriarAdmin(char cmp1[57], char cmp2[57], char login[30]);

//-----------------------FUNÇÕES------------------------

char Registrar(User *usuario) {
    char linha[57] = {0}, senha[40] = {0};
    int check, ch, a, j = 0;

    if(!usuario)
        return 1;

    if(ChecaLogin(usuario))
        return 2;

    strcpy(usuario->senha, senha);

    usuario->admin = 0;
    Criptografar(usuario->senha);

    FILE * fregistro = fopen("Dados/login.txt", "a");

    if(!fregistro) {
        printf("Erro na abertura do arquivo\n");
        exit(1);
    }
    check = 1;

    if(!fseek(fregistro, 0, SEEK_END))
        check = ftell(fregistro);

    if(!check)
        usuario->admin = 1;

    fprintf(fregistro, "%s:%s:%c\n", usuario->login, usuario->senha, usuario->admin ? '1' : '0');
    fclose(fregistro);
    return 0;
}

char Autenticar(User* usuario) {
    if(!usuario) return 0;
    
    char linha[57] = {0}, cmp[57] = {0};
    FILE * fleitura;

    fleitura = fopen("Dados/login.txt", "r");

    if(fleitura == NULL) {
        printf("Erro na abertura do arquivo\n");
        exit(1);
    }
    Criptografar(usuario->senha);

    strcpy(cmp, usuario->login);
    strcat(cmp, ":");
    strcat(cmp, usuario->senha);
    
    if(usuario->admin)
        strcat(cmp, ":1");
    else
        strcat(cmp, ":0");

    while(!feof(fleitura)) {
        fgets(linha, 57, fleitura);

        for(size_t i = 0; i<57; i++) {
            if(linha[i] != '\n')
                continue;
            linha[i] = 0;
            break;
        }
        if(strcmp(cmp, linha) == 0) {
            fclose(fleitura);
            return 1;
        }
        if(feof(fleitura)) {
            break;
        }
    }
    fclose(fleitura);

    return 0;
}

char ChecaLogin(User *usuario) {
    char linha[57]= {0};
    int check = 0;
    FILE * fcheca_login;

    fcheca_login = fopen("Dados/login.txt", "r");

    if(fcheca_login == NULL) {
        printf("Erro na abertura do arquivo\n");
        exit(1);
    }
    for(int i=0; i<strlen(usuario->login); i++) {
        if (usuario->login[i] == ':' || strlen(usuario->login) == 0)
            check++;
    }
    while(!feof(fcheca_login)) {
        fgets(linha, 57, fcheca_login);
        strtok(linha, ":");

        if(strcmp(linha, usuario->login) == 0 || check) {
            fclose(fcheca_login);
            return 1;
        }
    }
    fclose(fcheca_login);
    return 0;
}

void VirarAdmin(char login[30]) {
    long int inicioLinha=0;
    char linha[57]= {0}, check[30] = {0};
    int tam, cont = 0, i = 0;
    FILE * fleitura;

    fleitura = fopen("Dados/login.txt", "r+");

    if(fleitura == NULL) {
        printf("Erro na abertura do arquivo\n");
        exit(1);
    }
    system("clear");

    inicioLinha = ftell( fleitura );

    while(!feof(fleitura)) {
        fgets(linha, 57, fleitura);

        for(size_t i = 0; i<57; i++) {
            if(linha[i] != '\n')
                continue;
            linha[i] = 0;
            break;
        }
        strcpy(check, linha);
        strtok(check, ":");

        if(strcmp(login, check) == 0) {
            tam = strlen(linha);

            fseek(fleitura, inicioLinha, SEEK_SET);

            for(i = 0; i < tam; i++) {
                if(linha[i] != ':') {
                    putc((linha[i]), fleitura);
                    continue;
                }
                cont++;
                putc((char) ':', fleitura);
    
                if(cont == 2)
                    break;
            }
            i++;

            if(linha[i] == 1) {
                putc((char) '1', fleitura);
                printf("O usuário %s já é administrador!\n", login);
            }
            else
                printf("O usuário %s se tornou administrador!\n", login);

            printf("Voltando para o menu...\n");
            sleep(2);

            fclose(fleitura);
            return;
        }
        inicioLinha = ftell( fleitura );

        if(feof(fleitura)) {
            printf("O usuário %s não foi econtrado!\n", login);

            printf("Voltando para o menu...\n");
            sleep(2);

            fclose(fleitura);
            return;
        }
    }
    printf("O usuário %s não foi econtrado!\n",login);

    printf("Voltando para o menu...\n");
    sleep(2);

    fclose(fleitura);
    return;
}

void CriarAdmin(char cmp1[57], char cmp2[57], char login[30]) {
    char linha[57];
    FILE * fleitura;

    fleitura = fopen("Dados/login.txt", "r+");

    if(fleitura == NULL) {
        printf("Erro na abertura do arquivo\n");
        exit(1);
    }
    system("clear");

    while(!feof(fleitura)) {
        fgets(linha, 57, fleitura);

        for(size_t i = 0; i<57; i++) {
            if(linha[i] != '\n')
                continue;
            linha[i] = 0;
            break;
        }
        if(strcmp(cmp2, linha) == 0) {
            printf("O usuário %s já é administrador!\n", login);

            printf("Voltando para o menu...\n");
            sleep(2);

            fclose(fleitura);
            return;
        }
        if(strcmp(cmp1, linha) == 0) {
            printf("O usuário %s já existe!\n\n", login);
            printf("Deseja tornar o usuário %s um administrador?", login);
            printf("\n1 - SIM, 0 - NÃO\n");

            printf("Sua resposta é: ");
            int opc = getchar();

            if (opc == '1')
                VirarAdmin(login);

            fclose(fleitura);
            return;
        }
        if(feof(fleitura)) {
            fprintf(fleitura, "%s\n", cmp2);
            printf("O usuário %s foi criado como administrador!\n", login);

            printf("Voltando para o menu...\n");
            sleep(2);

            fclose(fleitura);
            return;
        }
    }
    fprintf(fleitura, "%s\n", cmp2);
    printf("O usuário %s foi criado como administrador!\n", login);

    printf("Voltando para o menu...\n");
    sleep(2);

    fclose(fleitura);
    return;
}

#endif