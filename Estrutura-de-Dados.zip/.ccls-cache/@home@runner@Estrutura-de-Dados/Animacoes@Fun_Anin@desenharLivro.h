#ifndef  _DESENHAR_LIVRO_
#define _DESENHAR_LIVRO_

#include <stdio.h>
#include <stdlib.h>

#include "listaStr.h"

//-------------------FUNCIONALIDADES--------------------

void DrawTopoLivro();
void DrawBottomLivro();
void DrawLine(int quant);
void TextDraw(char* c, char* cor);
void TextArrayDraw(int quant, char* nome[quant], char* cor);
void TextDrawInLine(char* c, char* cor);
void TextDrawWithMask(char* c, char* cor, char mask);

listaStr* lista1 = NULL;
listaStr* lista2 = NULL;
listaStr* lst1 = NULL;
listaStr* lst2 = NULL;
int high = 10;
char begin = 0;
char manterStr = 0;

//-----------------------FUNÇÕES------------------------

void DrawBegin(){
    lista1 = InitListaStr(lista1);
    lista2 = InitListaStr(lista2);
    if(manterStr != 1){
        if(manterStr == 3 || !manterStr)
            ClearListStr(lista1);
        if(manterStr == 2 || !manterStr)
            ClearListStr(lista2);
    }
    begin = 1;
}

inline void HoldText(int _opc) {
    if(_opc == 'L' || _opc == 'l') _opc = 2;
    if(_opc == 'R' || _opc == 'r') _opc = 3;
    if(_opc < 1 || _opc > 3) _opc = 1;
    manterStr = _opc;
}

void LoadText(){
    if(lst1){
        for(str_no* no = lst1->ini; no != lst1->fim; no = no->prox){
            PushBackStr(lista1, no->str, no->cor);
        }
    }
    if(lst2){
        for(str_no* no = lst2->ini; no != lst2->fim; no = no->prox){
            PushBackStr(lista2, no->str, no->cor);
        }
    }
}

void UnsaveText(char _opc){
    switch(_opc){
        case 1:
            ClearListStr(lst1);
            ClearListStr(lst2);
        break;
        case 2:
        case 'L':
        case 'l':
            ClearListStr(lst1);
        break;
        case 3:
        case 'R':
        case 'r':
            ClearListStr(lst2);
        break;
    }
}

void SaveText(char _opc){
    switch(_opc){
        case 1:
            lst1 = InitListaStr(lst1);
            lst2 = InitListaStr(lst2);
            ClearListStr(lst1);
            ClearListStr(lst2);
            for(str_no* no = lista1->ini; no != lista1->fim; no = no->prox){
                PushBackStr(lst1, no->str, no->cor);
            }
            for(str_no* no = lista2->ini; no != lista2->fim; no = no->prox){
                PushBackStr(lst2, no->str, no->cor);
            }
        break;
        case 2:
        case 'L':
        case 'l':
            lst1 = InitListaStr(lst1);
            ClearListStr(lst1);
            for(str_no* no = lista1->ini; no != lista1->fim; no = no->prox){
                PushBackStr(lst1, no->str, no->cor);
            }
        break;
        case 3:
        case 'R':
        case 'r':
            lst2 = InitListaStr(lst2);
            ClearListStr(lst2);
            for(str_no* no = lista2->ini; no != lista2->fim; no = no->prox){
                PushBackStr(lst2, no->str, no->cor);
            }
        break;
    }
}

void DrawTextLeft(char* c, char* cor){
    if(!begin || !lista1) return;
    PushBackStr(lista1, c, cor);
}

void DrawTextRight(char* c, char* cor){
    if(!begin || !lista2) return;
    PushBackStr(lista2, c, cor);
}

void DrawTextLine(char* c, char* cor){
    int _size = 0;
    int meio;
    if(c){
        while(c[_size++]);
        _size--;
    }
    
    if(_size > 18){
        char* aux = (char*)malloc(19);
        if(!aux) return;
        
        int cont = 0;
        
        while(cont < _size){
            int cont2 = 0;
            while(cont2 < 18 && c[cont]){
                aux[cont2++] = c[cont++];
            }
            aux[cont2] = 0;
            
            
            char has = 0;
            
            if(cont < _size){
                has = c[cont+1] != ' ';
            }
            if(has){
                int cont3 = cont2;
                while(cont3 > 0){
                    if(aux[cont3] == ' ') break;
                    cont3--;
                }
                if(cont3 > 0){
                    aux[cont3] = 0;
                    cont -= (cont2 - cont3);
                }
            }
            
            TextDraw(aux, cor);
        }
        free(aux);
        return;
    }
    
    meio = _size / 2;
    printf("\033[30;47m| ");

    for(int i = 9 - meio; i>0; i--)
        printf("_");

    if(cor)
        printf(cor);
    if(_size)
        printf("%s", c);
    
    printf("\033[30;47m");

    meio = _size - meio;

    for(int i = 9 - meio; i>0; i--)
        printf("_");
    printf(" |");
}

void DrawTextSpace(char _opc){
    switch(_opc){
        case 1:
            PushBackStr(lista1, NULL, NULL);
            PushBackStr(lista2, NULL, NULL);
        break;
        case 2:
        case 'l':
        case 'L':
            PushBackStr(lista1, NULL, NULL);
        break;
        case 3:
        case 'r':
        case 'R':
            PushBackStr(lista2, NULL, NULL);
        break;
    }
}

void DrawEnd(){
    DrawTopoLivro();
    str_no* no1 = lista1->ini;
    str_no* no2 = lista2->ini;
    printf("\n");
    DrawTextLine(NULL, NULL);
    printf(" ");
    DrawTextLine(NULL, NULL);
    for(int i = 0; i<high; i++){
        printf("\n");
        if(no1 != lista1->fim) {
            DrawTextLine(no1->str, no1->cor);
            no1 = no1->prox;
        }else DrawTextLine(NULL, NULL);
        printf(" ");
        if(no2 != lista2->fim) {
            DrawTextLine(no2->str, no2->cor);
            no2 = no2->prox;
        }else DrawTextLine(NULL, NULL);
    }
    DrawBottomLivro();
    if(manterStr != 1){
        if(manterStr == 3 || !manterStr)
            ClearListStr(lista1);
        if(manterStr == 2 || !manterStr)
            ClearListStr(lista2);
    }
    begin = 0;
    printf("\x1B[0m");
}

void DrawTopoLivro() {
    printf("\033[30;47m   ═════════════             ═════════════   ");
    printf("\n ╔/             \\═══     ═══/             \\╗ ");
    printf("\n║                   ╚   /                   ║");
    printf("\x1B[0m");
}

void DrawBottomLivro() {
    printf("\033[30;47m\n║  ═════════════     ║ ║     ═════════════  ║");
    printf("\n|_/%13s\\___ | | ___/%13s╚═╣", "", "");
    printf("\n|%19s\\___/%19s|", "", "");
    printf("\n ╚%41s/ ", "");
    printf("\n  ╚════════════════       ════════════════/  ");
    printf("\n%19s╚═════/%19s", "", "");
    printf("\x1B[0m");
}

void DrawLine(int quant){
    if(quant < 0)
        quant *= -1;
    printf("\033[30;47m");

    while(quant--) {
        printf("\n| ");

        for(int i = 18; i>0; i--)
            printf("_");
        printf(" | | ");

        for(int i = 18; i>0; i--)
            printf("_");
        printf(" |");
    }
    printf("\x1B[0m");
}

void TextDraw(char* c, char* cor) {
    int _size = 0;
    int meio;

    while(c[_size++]);
    _size--;

    if(_size > 18){
        char* aux = (char*)malloc(19);
        if(!aux) return;
        
        int cont = 0;
        
        while(cont < _size){
            int cont2 = 0;
            while(cont2 < 18 && c[cont]){
                aux[cont2++] = c[cont++];
            }
            aux[cont2] = 0;
            
            
            char has = 0;
            
            if(cont < _size){
                has = c[cont+1] != ' ';
            }
            if(has){
                int cont3 = cont2;
                while(cont3 > 0){
                    if(aux[cont3] == ' ') break;
                    cont3--;
                }
                if(cont3 > 0){
                    aux[cont3] = 0;
                    cont -= (cont2 - cont3);
                }
            }
            
            TextDraw(aux, cor);
        }
        free(aux);
        return;
    }
    meio = _size / 2;
    printf("\033[30;47m\n| ");

    for(int i = 9 - meio; i>0; i--)
        printf("_");

    if(cor[0] != '\0' && cor)
        printf(cor);

    printf("%s", c);
    printf("\033[30;47m");

    meio = _size - meio;

    for(int i = 9 - meio; i>0; i--)
        printf("_");
    printf(" | | ");

    for(int i = 18; i>0; i--)
        printf("_");
    printf(" |");
    printf("\x1B[0m");
}

void TextArrayDraw(int quant, char* nome[quant], char* cor) {
    for(int i = 0; i<quant; i++) {
        int size = 0;
        int meio;
    
        while(nome[i][size++]);
        size--;

        if(size > 20)
            continue;
        printf("\033[30;47m\n|");

        meio = size / 2;

        for(int j = 8 - meio; j>0; j--)
            printf("_");

        if(cor[0] != '\0' && cor)
            printf(cor);
        printf("%s", nome[i]);

        meio = size - meio;

        for(int j = 8 - meio; j>0; j--)
            printf("_");
        printf("\033[30;47m | | ");
    }
    printf("\x1B[0m");
}

void TextDrawInLine(char* c, char* cor) {
    int _size = 0;
    int meio;

    while(c[_size++]);
    _size--;

    printf("\033[30;47m\n| ");

    if(_size > 18) {
        int diff = _size - 18;
        c = &c[diff];
    }
    meio = _size / 2;

    for(int i = 9 - meio; i>0; i--)
        printf("_");

    if(cor[0] != '\0' && cor)
        printf(cor);
    printf("%s", c);
    printf("\033[30;47m");

    meio = _size - meio;

    for(int i = 9 - meio; i>0; i--)
        printf("_");
    printf(" | | ");

    for(int i = 18; i>0; i--)
        printf("_");
    printf(" |");
    printf("\x1B[0m");
}

void TextDrawWithMask(char* c, char* cor, char mask) {
    int _size = 0;
    int meio;

    while(c[_size++]);
    _size--;

    printf("\033[30;47m\n| ");

    if(_size > 18)
        return;
    meio = _size / 2;

    for(int i = 9 - meio; i>0; i--)
        printf("_");

    if(cor[0] != '\0' && cor)
        printf(cor);

    for(int i = 0; i < _size; i++)
        printf("*");
    printf("\033[30;47m");

    meio = _size - meio;

    for(int i = 9 - meio; i>0; i--)
        printf("_");
    printf(" | | ");

    for(int i = 18; i>0; i--)
        printf("_");
    printf(" |");
    printf("\x1B[0m");
}

#endif