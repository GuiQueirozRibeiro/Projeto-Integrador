#ifndef _PAGAMENTO_
#define _PAGAMENTO_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#include "crypto.h"
#include "structs.h"
#include "term.h"

#define HideCursor() printf("\e[?25l");
#define ShowCursor() printf("\e[?25h");

//-------------------FUNCIONALIDADES--------------------

void AdicionarCartao(User *usuario);
void RemoverCartao(User *usuario);
char VerificarCartao(int num[16]);
void MostrarCartao(User *usuario);

//-----------------------FUNÇÕES------------------------

void AdicionarCartao(User *usuario) {
    int cartao_i[16];
    int cartao_o[16];
    int data_i[4];
    int data_o[4];
    char titular_i[30] = {0};
    char titular_o[30] = {0};
    int data;
    int check;
    int status = 0;
    int j = 0;
    char ch; 

    FILE * fregistro = fopen("Dados/cartoes.txt", "r+");

    if(!fregistro) {
        printf("Falha ao adicionar o cartão\n");
        sleep(3);
        exit(1);
    }
    tc_echo_off();
    tc_canon_off();

    fprintf(fregistro, "%s:", usuario->login);
    printf("\e[H\e[2J");
    printf("Número do cartao = ");

    while (j < 17) {
        ch = getchar();
    
        if (j == 0) {
            SetCursorPosition(20,5);
            if (ch - 48 == 3)
                printf("American Express");
            else
                if (ch - 48 == 4)
                    printf("Visa");
            else
                if (ch - 48 == 5)
                    printf("MasterCard");
            else {
                SetCursorPosition(20, 1);
                continue;
            }
            SetCursorPosition(20, 1);
        }
        if (j % 4 == 0 && j!= 0)
            printf("-");
        if (ch > 47 && ch < 58 && j < 16) {
            cartao_i[j] = ch -48;
            cartao_o[j] = CriptoRSA(ch, 2);
            printf("%d", cartao_i[j]);
            j++;
        }
        if (ch == 127) {
			if(!j)
                continue;
			--j;
            cartao_i[j] = 0;
            cartao_o[j] = 0;

			printf("\e[H\e[2J");
            printf("Número do cartao = ");

			for(int a = 0; a < j; a++) {
                if (a == 0) {
                    SetCursorPosition(20,5);
                    if (cartao_i[a] == 3)
                        printf("American Express");
                    else
                        if (cartao_i[a] == 4)
                            printf("Visa");
                    else
                        if (cartao_i[a] == 5)
                            printf("MasterCard");
                    else {
                        SetCursorPosition(20, 1);
                        continue;
                    }
                    SetCursorPosition(20, 1);
                }
                if(a % 4 == 0 && a!= 0)
                    printf("-");
                printf("%d", cartao_i[a]);
            }
		}
        if (j == 16) {
            status = VerificarCartao(cartao_i);
            if (status)
                break;
            printf("\e[H\e[2J");
            printf("Número do cartao = ");

			for(int a = 0; a < j; a++) {
                if (a == 0) {
                    SetCursorPosition(1,2);
                    printf(TC_YEL);
                    printf("ERRO-Cartão inválido!!!");
                    SetCursorPosition(20,5);
                    if (cartao_i[a] == 3)
                        printf("American Express");
                    else
                        if (cartao_i[a] == 4)
                            printf("Visa");
                    else
                        if (cartao_i[a] == 5)
                            printf("MasterCard");
                    else {
                        SetCursorPosition(20, 1);
                        continue;
                    }
                    SetCursorPosition(20, 1);
                }
                if(a % 4 == 0 && a!= 0)
                    printf("-");
                printf(TC_RED);
                printf("%d", cartao_i[a]);
            }
            printf(TC_RST);
        }
    }
    for (int j = 0; j < 16; j++)
        fprintf(fregistro, "%c", cartao_o[j]);
    fprintf(fregistro, ":");

    j = 0;

    do {
        status = 0;
        data = 0;
        printf("\e[H\e[2J");
        printf("Número do cartao = ");

		for(int a = 0; a < 16; a++) {
            if (a == 0) {
                SetCursorPosition(20, 5);
                if (cartao_i[a] == 3)
                    printf("American Express");
                else
                    if (cartao_i[a] == 4)
                        printf("Visa");
                else
                    if (cartao_i[a] == 5)
                        printf("MasterCard");
                else {
                    SetCursorPosition(20, 1);
                    continue;
                }
                SetCursorPosition(20, 1);
            }
            if(a % 4 == 0 && a!= 0)
                printf("-");
            printf("%d", cartao_i[a]);
        }
        printf("\nData de validade do cartao = ");

        for (int j = 0; j < 4; j++) {
            if(j == 2)
                printf("/");
            ch = getchar();
            data_i[j] = ch - 48;
            printf("%d", data_i[j]);
            data_o[j] = CriptoRSA(data_i[j], 3);
        }
        struct tm *data_hora_atual;  
    
        time_t segundos;
        time(&segundos);   
    
        data_hora_atual = localtime(&segundos);
        int tm_mday;
        int tm_year;
    
        check = ((data_i[2] *10) + data_i[3]) + 100;

        if (check == data_hora_atual->tm_year)
                data++;
        if (check < data_hora_atual->tm_year ||                     check > data_hora_atual->tm_year + 5) {
            printf("\e[H\e[2J");
            printf("Data inválida!");
            printf("\nTente um ano válido!\n");
            status++;
            sleep(3);
        }
        else {
            check = ((data_i[0] *10) + data_i[1]);
            if (data) {
                if (check < data_hora_atual->tm_mday || check > 12) {
                    printf("\e[H\e[2J");
                    printf("Data inválida!");
                    printf("\nTente um mês válido!\n");
                    status++;
                    sleep(3);
                }
            }
            else {
                if (check < 0 || check > 12) {
                    printf("\e[H\e[2J");
                    printf("Data inválida!");
                    printf("\nTente um mês válido!\n");
                    status++;
                    sleep(3);
                }
            }
        }
    } while (status);

    for (int a = 0; a < 4; a++)
        fprintf(fregistro, "%c", data_o[j]);
    fprintf(fregistro, ":");

    printf("\nDigite o nome do titular = ");
    j = 0;

    while (j < 30) {
        ch = getchar();
    
        if (ch == 127) {
			if(!j)
                continue;
			--j;
            titular_i[j] = 0;
            titular_o[j] = 0;

			printf("\e[H\e[2J");
            printf("Número do cartao = ");

    		for(int a = 0; a < 16; a++) {
                if (a == 0) {
                    SetCursorPosition(20,5);
                    if (cartao_i[a] == 3)
                        printf("American Express");
                    else
                        if (cartao_i[a] == 4)
                            printf("Visa");
                    else
                        if (cartao_i[a] == 5)
                            printf("MasterCard");
                    else {
                        SetCursorPosition(20, 1);
                        continue;
                    }
                    SetCursorPosition(20, 1);
                }
                if(a % 4 == 0 && a!= 0)
                    printf("-");
                printf("%d", cartao_i[a]);
            }
            printf("\nData de validade do cartao = %d%d/%d%d", data_i[0], data_i[1], data_i[2], data_i[3]);
            printf("\nDigite o nome do titular = ");

			for(int a = 0; a < j; a++)
                printf("%c", titular_i[a]);
		}
        if (ch > 96 && ch < 123) {
            titular_i[j] = ch - 32;
            titular_o[j] = CriptoRSA(ch, 5);
            printf("%c", titular_i[j]);
            j++;
        }
        if (ch > 64 && ch < 91) {
            titular_i[j] = ch;
            titular_o[j] = CriptoRSA(ch, 5);
            printf("%c", titular_i[j]);
            j++;
        }
        if (ch == 32) {
            titular_i[j] = ch;
            titular_o[j] = CriptoRSA(ch, 5);
            printf("%c", titular_i[j]);
            j++;
        }
        if (ch == 10)
            break;
    }
    for (int a = 0; a < j; a++)
        fprintf(fregistro, "%c", titular_o[j]);
    fclose(fregistro);

    printf("\e[H\e[2J");
    printf("Cartão XXXX-XXXX-XXXX-%d%d%d%d\nRegistrado com Sucesso!", cartao_i[12], cartao_i[13], cartao_i[14], cartao_i[15]);
    printf("\nVoltando para o menu...\n");
    sleep(4);
}

void RemoverCartao(User *usuario) {
    char linha[80] = {0};
    char login[80] = {0};
    char cmp[30] = {0};
    char* ptr;
    int i = 0;

    system("clear");

    struct tm *data_hora_atual;  

    time_t segundos;
    time(&segundos);   

    data_hora_atual = localtime(&segundos);

    FILE * input = fopen("aluguel.txt", "r");
    FILE * output = fopen("transferindo.txt", "w");

    if(!input || !output) {
        printf("Erro na abertura do arquivo\n");
        exit(1);
    }
    while(!feof(input)) {

        if(feof(input))
            break;
        memset(linha, 0, 80);
        memset(login, 0, 80);

        fgets(linha, 57, input);

        strcpy(login, linha);
        ptr = strtok(login, ":");

        if(strcmp(login, usuario->login) == 0) {
            ptr = strtok(NULL, ":");
            strcpy(cmp, ptr);
            i++;
        }
        else 
            fputs(linha, output);
    }
    fclose(input);
    fclose(output);
        
    remove("aluguel.txt");
    rename("transferindo.txt", "aluguel.txt");

    system("clear");

    printf("\nVoltando para o menu...\n");
    sleep(4);
}

char VerificarCartao(int num[16]) {
    int check[16];
    int verificador = 0;
    int cont = 0;

    for (int i = 0; i < 15; i++) {
        if (i+1 % 2 == 0)
            check[i] = num[i];
        else 
            check[i] = num[i] * 2;
    }
    for (int i = 0; i < 15; i++)
        verificador = verificador + check[i];
    while (verificador != 0) {
        if (verificador > 10)
            verificador = verificador - 10;
        else {
            verificador--;
            cont++;
        }
    }
    if (cont >= 5)
        cont = 10 - cont;
    if (num[15] == cont)
        return 1;
    else
        return 0;
}

void MostrarCartao(User *usuario) {
    char linha[80] = {0};
    char check[80] = {0};
    char titulo[30] = {0};
    char* ptr;
    int dia;

    struct tm *data_hora_atual;     
 
    time_t segundos;
    time(&segundos);   

    data_hora_atual = localtime(&segundos);

    FILE * fleitura = fopen("aluguel.txt", "r");

    if(!fleitura) {
        printf("Erro na abertura do arquivo\n");
        exit(1);
    }
    while(!feof(fleitura)) {

        if(feof(fleitura))
            break;
        memset(linha, 0, 80);
        memset(check, 0, 80);

        fgets(linha, 57, fleitura);

        for(size_t j = 0; j<57; j++) {
            if(linha[j] != '\n')
                continue;
            linha[j] = 0;
            break;
        }
        strcpy(check, linha);
        ptr = strtok(check, ":");

        if(strcmp(check, usuario->login) == 0) {
            ptr = strtok(NULL, ":");
            strcpy(titulo, ptr);
            ptr = strtok(NULL, ":");
            dia = atoi(ptr);

            if (dia > data_hora_atual->tm_yday) {
                if (dia >= data_hora_atual->tm_yday+358) {
                    fclose(fleitura);
                }
            }
            else if(dia +7 <= data_hora_atual->tm_yday) {
                fclose(fleitura);
            }
        }
    }
    fclose(fleitura);
}

#endif