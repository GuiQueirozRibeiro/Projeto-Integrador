#ifndef _BIBLIOTECA_
#define _BIBLIOTECA_

#include <stdio.h>
#include <stdlib.h>

#include "listaAutor.h"
#include "listaLivro.h"
#include "structs.h"
#include "term.h"

#define ull unsigned long long

//-------------------FUNCIONALIDADES--------------------

char NameHas(char* buff1, char* buff2);
void Upper_Case(char* frase);
listaLivro* ShowBiblioteca(int pagina, int *totalPagina, int livrosPagina);
Livro BuscarLivroCod(ull cod);
void Buscar_Livro(listaLivro*, char* nome, size_t pagina, char quant);
int Add_Livro(Livro livro);
int Remove_Livro(char* titulo);
void BuscarAutor(listaAutor* lista, char* nome, size_t quant);

//-----------------------FUNÇÕES------------------------

char NameHas(char* buff1, char* buff2) {
    size_t i = 0;
    size_t j = 0;
    size_t pos = i;
    char resp = 0;

    while(buff1[i] && buff2) {
        if(buff1[i++] != buff2[0]) {
            j = 0;
            continue;
        }
        resp = 1;
        pos = i;
        j = 1;

        while(buff1[i] && buff2[j]) {
            if(buff1[i++] != buff2[j++]) {
                j = 0;
                i = pos;
                resp = 0;
                break;
            }
        }
        resp = !buff2[j];
        i = pos;

        if(resp)
            break;
    }
    return resp;
}

listaLivro* ShowBiblioteca(int pagina, int *totalPagina, int livrosPagina) {
    Livro livro;
    listaLivro* livros = InitList(livros);
    
    char quantLivros = 0;
    int resp;
    ull quant;
    ull move = pagina * sizeof(Livro) * livrosPagina;

    FILE* arq = fopen("Dados/livros.txt", "rb");
    if(!arq) {
        printf("Falha ao abrir 'livros.txt'.\n");
        getchar();

        return ClearList(livros);
    }

    fread(&quant, sizeof(ull), 1, arq);
    *totalPagina = quant / livrosPagina + (quant % livrosPagina ? 1 : 0);

    if(fseek(arq, move, SEEK_CUR) == EOF) {
        printf("Pagina nao encontrada.\n");
        getchar();
        fclose(arq);

        return ClearList(livros);
    }

    while(fread(&livro, sizeof(Livro), 1, arq)) {
        PushBack(livros, livro);
        quantLivros++;
        if(quantLivros >= livrosPagina)
            break;
    }
    getchar();
    fclose(arq);
    
    return livros;
}

Livro BuscarLivroCod(ull cod) {
    Livro livro;
    livro.codigo = 0;

    FILE* arq = fopen("Dados/livros.txt", "rb");

    if(!arq) {
        printf("\nFalha ao abrir arquivo 'livros.txt'\n");

        return livro;
    }
    fread(NULL, sizeof(ull), 1, arq);
    
    if(feof(arq) || ferror(arq)) {
        fclose(arq);

        return livro;
    }

    while(fread(&livro, sizeof(Livro), 1, arq) != EOF) {
        if(feof(arq) || ferror(arq)) {
            break;
        }
        if(!livro.quantidade)
            continue;
        if(livro.codigo == cod)
            break;
    }
    return livro;
}

void Buscar_Livro(listaLivro* lista, char* nome, size_t pagina, char quant) {
    Livro livro;
    ull quantLivros;
    ull _cod = 0;
    int contLivro = 0;
    size_t paginaAtual = 0;

    if(!lista) lista = InitList(lista);

    Upper_Case(nome);

    FILE* arq = fopen("Dados/livros.txt", "rb");

        if(!arq) {
        printf("\nFalha ao abrir arquivo 'livros.txt'\n");

        return;
    }

    fread(&quantLivros, sizeof(ull), 1, arq);
    
    if(feof(arq) || ferror(arq)) {
        fclose(arq);

        return;
    }

    while(fread(&livro, sizeof(Livro), 1, arq) != EOF) {
        char igual = NameHas(livro.titulo, nome);

        if(feof(arq) || ferror(arq))
            break;

        if(!livro.quantidade)
            continue;

        if(igual && pagina == paginaAtual) {
            PushBack(lista, livro);
            contLivro++;
        }
        else if(igual)
            contLivro++;

        if(contLivro>=quant) {
            contLivro = 0;
            paginaAtual++;
            if(paginaAtual > pagina)
                break;
        }
    }
    fclose(arq);

    return;
}

int Add_Livro(Livro livro) {
    ull quant = 0;

    Upper_Case(livro.titulo);

    FILE* arq = fopen("Dados/livros.txt", "r+b");

    if(!arq) {
        printf("\nFalha ao abrir arquivo 'livros.txt'\n");

        return 0;
    }
    fread(&quant, sizeof(ull), 1, arq);

    if(!quant) {
        quant++;
        fwrite(&quant, sizeof(ull), 1, arq);
        livro.codigo = quant;
        fwrite(&livro, sizeof(Livro), 1, arq);
        fclose(arq);

        return 1;
    }
    Livro book;
    fpos_t posi;
    fgetpos(arq, &posi);
  
    while(fread(&book, sizeof(Livro), 1, arq)) {
        char igual = 1;

        if(feof(arq))
            break;

        for(int i = 0;;i++) {
          if(book.titulo[i] == livro.titulo[i]) {
            if(!book.titulo[i])
                break;
            continue;
          }
          igual = 0;
          break;
        }

        if(!igual) {
            fgetpos(arq, &posi);
            continue;
        }
        fsetpos(arq, &posi);
        book.quantidade++;
        fwrite(&book, sizeof(Livro), 1, arq);
        fclose(arq);

        return 1;
    }
    ++quant;

    rewind(arq);
    fwrite(&quant, sizeof(ull), 1, arq);

    freopen("Dados/livros.txt", "ab", arq);
    livro.codigo = quant;
    fwrite(&livro, sizeof(Livro), 1, arq);
    fclose(arq); 
  
    return 1;
}

int Remove_Livro(char* titulo) {
    int quant = 0;
    Livro livro;
    fpos_t posi;

    Upper_Case(titulo);

    FILE* arq = fopen("Dados/livros.txt", "r+b");

    if(!arq) {
        printf("\nFalha ao abrir arquivo 'livros.txt'\n");
        getchar();

        return 0;
    }
    fread(&quant, sizeof(ull), 1, arq);

    if(!quant) {
        printf("\nLivro nao encontrado!");
        fclose(arq);
        getchar();

        return 2;
    }
    fgetpos(arq, &posi);

    while(fread(&livro, sizeof(Livro), 1, arq) != EOF) {
        char igual = 1;

        if(feof(arq)) {
            printf("\nLivro nao encontrado!");
            fclose(arq);
            getchar();

            return 2;
        }
        for(int i = 0;;i++) {
            if(livro.titulo[i] == titulo[i]) {
                if(!livro.titulo[i])
                    break;
                continue;
            }
            igual = 0;
            break;
        }
        if(!igual) {
            fgetpos(arq, &posi);
            continue;
        }
        fsetpos(arq, &posi);
        livro.quantidade -= livro.quantidade ? 1 : 0;
        fwrite(&livro, sizeof(Livro), 1, arq);
        break;
    }
    fclose(arq);
    printf("\nLivro removido!");
    getchar();

    return 1;
}

void BuscarAutor(listaAutor* lista, char* nome, size_t quant) {
    Autor autor;
    size_t tam = !quant || quant > 100 ? 100 : quant;

    Upper_Case(nome);

    FILE* file = fopen("Dados/autores.txt", "rb");

    if(!file) {
        system("clear");
        printf("\nFalha ao abrir arquivo 'autores.txt'\n");
        fclose(file);

        return;
    }
    fread(NULL, sizeof(ull), 1, file);

    while(fread(&autor, sizeof(Autor), 1, file) != EOF) {
        if(feof(file))
            break;

        if(NameHas(autor.nome, nome)) {
            PushBackA(lista, autor);
            if(!--tam)
                break;
        }
    }
    fclose(file);
    return;
}

void BuscarAutorCod(ull cod, Autor* autor){
    Autor aux;
    autor = NULL;
    FILE* file = fopen("Dados/autores.txt", "rb");

    if(!file) return;

    fread(NULL, sizeof(ull), 1, file);
    while(!feof(file)){
        fread(&aux, sizeof(Autor), 1, file);
        if(aux.cod == cod){
            fclose(file);
            *autor = aux;
            return;
        }
    }
    return;
}

#endif