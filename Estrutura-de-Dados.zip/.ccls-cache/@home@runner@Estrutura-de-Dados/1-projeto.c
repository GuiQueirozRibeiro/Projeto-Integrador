#include <stdio.h>
#include <stdlib.h>
#include "Structs.h"
#include "login.h"
#include "biblioteca.h"
#include "listaLivro.h"
#include "term.h"

#ifdef __WIN32__
#include <windows.h>
  void SetCursorPosition (short x, short y){
    COORD Coord;
    Coord.X = XPos;
    Coord.Y = YPos;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), Coord);
  }
#else
  void SetCursorPosition (short x, short y){
    printf("\033[%d;%dH", y, x);
  }
#endif

void ClearEndLine();
//-----------------------MENUS--------------------------
void menu_admin();
void menu_cliente();
//-------------------FUNCIONALIDADES--------------------
void ShowLivro(Livro livro);
void adc_liv();
void MostrarBiblioteca();
void RemoverLivro();

void Procurar(){
  system("clear");
  tc_echo_on();
  tc_canon_off();
  size_t pagina = 0;
  char livroPorPagina = 20;
  char buff[41] = {0};
  size_t quant = 0;
  unsigned char resp;
  listaLivro* livrosAux = NULL;
  char fim = 0;
  char posiY = 0;
  while(!fim){
    printf(TC_WHT);
    printf(TC_BG_NRM);
    printf("Digite o nome do Livro: %s", buff);
    if(livrosAux->size){
      char count = 0;
      for(t_noL* l = livrosAux->inicio; l != livrosAux->fim; l = l->proximo){
        printf(TC_RED);
        printf(TC_B_);
        count++;
        if(posiY == count){
          printf(TC_BLK)
          printf(TC_BG_WHT);
        }
        printf("\n%s.", l->livro.titulo);
      }
    }
    resp = getchar();
    switch(resp){
      case 13: fim = 1;
      break;
      case 27: return;
      break;
      case 8:
        if(!quant) break;
        quant--;
        buff[quant] = 0;
      break;
      case 224:
        resp = getchar();
        if(livrosAux->size == 0){
          
        }
      break;
      default:
        if((resp >= '0' && resp <= '9') || 
          (resp >= 'A' && resp <= 'Z') || 
          (resp >= 'a' && resp <= 'z'))
        {
          if(quant >= 40) break;
          buff[quant++] = resp;
          if(quant >= 3) {
            ClearList(livrosAux);
            livrosAux = Buscar_Livro(buff, pagina, 3);
          }
        }
    }
  }

  listaLivro* livros = Buscar_Livro(buff, pagina, livroPorPagina);
  while(1){
    if(!livros->size){
      printf("Livro não encontrado.");
      break;
    }
    else {
      short numLivros = 0;
      char numPag = (numLivros/20) + (numLivros % 20 ? 1 : 0);
      while(1){
        SetCursorPosition(1, 3);
        t_noL* node = livros->inicio;
        for(int i = 0; i<livros->size; i++){
          printf("\aLivro: %s\n", node->livro.titulo);
          printf("Cod: %llu\n", node->livro.codigo);
          node = node->proximo;
        }
        SetCursorPosition(1, 2);
        printf("1 - %lu: (0 - Voltar): ", livros->size);
        int resp;
        scanf("%d%*c", &resp);
        resp = resp < 0 ? -resp : resp;
        if(!resp) return;
        if(resp <= livros->size){
          t_noL* node = livros->inicio;
          for(int i = 1; i<resp; i++){
            node = node->proximo;
          }
          ShowLivro(node->livro);
        }
      }
    }
  }
  getchar();
}
//------------------------MAIN--------------------------

int main(void) {
  Livro * inicio_ptr1;
  User * usuario;
  
  int opc = 0;
  char fim = 0;
  while(!fim){
    tc_echo_off();
    tc_canon_off();
    do {
      system("clear");
      if (opc > 2){
          printf("\n\nSelecione uma opção válida!!!\n\n");
      }
      printf("MENU\n--------------------\n");
      printf("1 - Cadastro\n");
      printf("2 - Login\n");
      printf("0 - Sair!\n\n");
      opc = getchar() - '0';
    
    } while (opc != 1 && opc != 2 && opc != 0);
    tc_echo_on();
    tc_canon_on();
    switch (opc){
      case 1:
        registrar(usuario);
        break;
      case 2:
        if(!autenticar()) menu_admin();
        break;
      case 0:
        fim = 1;
        break;
    }   
  }   
    return 0;
}

//-----------------------FUNÇÕES------------------------
void ClearEndLine()
{
  while(getchar() != '\n');
}

void menu_admin()
{
  
  int opc;
  char fim = 0;
  while(!fim){
    do {
      tc_echo_off();
      tc_canon_off();
      system("clear");        
      printf("MENU\n--------------------\n");
      printf("1 - Adicionar livro\n");
      printf("2 - Remover livro\n");
      printf("3 - Buscar Livro\n");
      printf("4 - Mostrar Biblioteca\n");
      printf("0 - Sair!\n");
      opc = getchar() - '0';
    } while (opc < 0 || opc > 4);
    switch (opc) {
      case 1:
        adc_liv();
        break;
      case 2:
        RemoverLivro();        
        break;
      case 3:
        Procurar();
        break;
      case 4:
        MostrarBiblioteca();
        break;
      case 0:
        fim = 1;
        break;
    }
  }
}

void menu_cliente()
{
  int opc;
  char fim = 0;
  while(!fim){
    do {
      system("clear");        
      printf("MENU\n--------------------");
      printf("1 - Biblioteca\n");
      printf("2 - Buscar Livro\n");
      printf("0 - Sair!\n\n");
      printf("Sua opção é: ");
      scanf("%i%*c", &opc);
    
    } while (opc != 1 && opc != 0);

    switch (opc){
      case 1:
        MostrarBiblioteca();
        break;
      case 2:
        Procurar();
        break;
      case 0:
        fim = 1;
        break;
    }
  }
}

void ShowLivro(Livro livro)
{
  tc_echo_off();
  tc_canon_off();
  system("clear");
  printf("Nome: %s\n", livro.titulo);
  printf("Autor: %llu\n", livro.autor);
  printf("Cod: %llu\n", livro.codigo);
  getchar();
}

void adc_liv()
{
  Livro livro;
  tc_echo_on();
  tc_canon_on();
  system("clear");
  printf("NOVO LIVRO\n--------------------\n");
  printf("Insira seu título: ");
  scanf("%40[^\n]%*c", livro.titulo);
  livro.autor = 0;
  livro.titulo[40] = 0;
  livro.quantidade = 1;
  if(!Add_Livro(livro)) printf("Falha ao Adicionar Livro!");
}

void MostrarBiblioteca()
{
  tc_echo_on();
  tc_canon_on();
  int resp = 0;
  int pagina = 0;
  int totalPag;
  do{
    system("clear");
    listaLivro* livros = ShowBiblioteca(pagina, &totalPag, 20);
    if(!livros->size){
      printf("Erro: Nenhum livro encontrado.\n");
      getchar();
      break;
    }
    SetCursorPosition(1, 2);
    char i = 1;
    for(t_noL* node = livros->inicio; i<= livros->size;node = node->proximo){
      
      printf("%d - %s\n", i++, node->livro.titulo);
    }
    SetCursorPosition(1,1);
    printf("Pagina <%d - %d>(0-Voltar, '+' ou '-' para pagina): ", pagina+1, totalPag);
    char c, d;
    resp = 0;
    while((c = getchar()) != '\n'){
      resp *= 10;
      if(c >= '0' && c <= '9'){
        if(d == '+' || d == '-') resp = 0;
        resp += c - '0';
      }else{
        resp = c;
        d = c;
      }
      if(resp == '+' && (pagina+1) < totalPag) pagina++;
      else if(resp == '-' && (pagina+1) > 1) pagina--;
      else if(resp >= 1 && resp <= livros->size) {
        t_noL* node = livros->inicio;
        for(int i = 1; i<resp; i++){
          node = node->proximo;
        }
        ShowLivro(node->livro);
      }
    }
  }while(resp != 0);
}

void RemoverLivro()
{
  tc_echo_on();
  tc_canon_on();
  system("clear");
  char nome[41];
  nome[40] = 0;
  printf("Nome do livro: ");
  scanf("%40[^\n]%*c", nome);
  Remove_Livro(nome);
}