#ifndef _LIVROS_
#define _LIVROS_

#include "Structs.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

Livro Buscar_Livro(unsigned long long cod){
  Livro livro;
  livro.codigo = 0;
  FILE* arq;
  arq = fopen("livros.txt", "rb");
  if(!arq) printf("\nFalha ao abrir arquivo 'livros.txt'.\n");
  unsigned long long _cod = 0;
    printf("\nCOD: %llu\n", _cod);
  while(fread(&_cod, 8, 1, arq)){
  }
  return livro;
}

#endif //_LIVROS_