#ifndef _LISTA_KEY_
#define _LISTA_KEY_

#include <stdlib.h>
#include <stdio.h>

typedef struct NodeKey{
  unsigned char key;
  struct NodeKey *proximo;
  struct NodeKey *anterior;
}t_key;

typedef struct {
  size_t size;
  t_key *inicio;
  t_key *fim;
}listaKey;

listaKey* InitList(listaKey*);

void PushBack(listaKey* lista, unsigned char key){
  lista = InitList(lista);
  lista->fim->key = key;
  lista->fim->proximo = (t_key*)malloc(sizeof(t_key));
  if(!lista->fim->proximo) return;
  lista->fim->proximo->anterior = lista->fim;
  lista->fim = lista->fim->proximo;
  lista->fim->proximo = NULL;
  lista->size++;
}

void PushFront(listaKey* lista, unsigned char key){
  lista = InitList(lista);
  
  t_key* node = lista->inicio;

  lista->inicio = (t_key*)malloc(sizeof(t_key));
  lista->inicio->key = key;
  lista->inicio->proximo = node;
  node->anterior = lista->inicio;
  lista->inicio->anterior = NULL;
  lista->size++;
}

listaKey* InitList(listaKey* lista){
  if(lista != NULL) return lista;
  lista = (listaKey*)malloc(sizeof(listaKey));
  
  lista->size = 0;
  lista->inicio = (t_key*)malloc(sizeof(t_key));
  lista->fim = lista->inicio;
  lista->fim->proximo = NULL;
  lista->fim->anterior = NULL;

  return lista;
}

void PopBack(listaKey* lista){
  if(!lista->size) return;
  lista->fim->proximo = NULL;
  lista->fim = lista->fim->anterior;
  lista->fim->proximo = NULL;
  lista->size--;
}

void PopFront(listaKey* lista){
  if(!lista->size) return;
  t_key* node = lista->inicio->proximo;
  if(!node) return;
  free(lista->inicio);
  node->anterior = NULL;
  lista->inicio = node;
  lista->size--;
}

void Remove(t_key* node){
  if(!node->anterior){
    node = node->proximo;
  }else{
    node->anterior->proximo = node->proximo;
    free(node);
  }
}

listaKey* ClearList(listaKey* lista) {
  lista = InitList(lista);
  
  while(lista->fim->anterior){
    lista->fim = lista->fim->anterior;
    free(lista->fim->proximo);
  }
  lista->size = 0;
  lista->fim->proximo = NULL;
  return lista;
}

#endif //_LISTA_KEY_